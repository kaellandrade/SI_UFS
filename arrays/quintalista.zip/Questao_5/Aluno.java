public class Aluno {
    private String nome;
    private float media;

    public void setMedia(float media) {
        this.media = media;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return this.nome;
    }

    public float getMedia() {
        return this.media;
    }

}