public class Media {
    private int num1;
    private int num2;
    private int num3;

    public float calcMedia() {
        return (num1 + num2 + num3) / 3;
    }

    public void setNum1(int valor){
        num1 = valor;
    }

    public void setNum2(int valor){
        num2 = valor;
    }

    public void setNum3(int valor){
        num3 = valor;
    }

}
